#https://superuser.com/questions/666119/how-to-allow-user-to-input-file-names-in-bash-script
input=$1
input2=$2
input3=$3
inputDirective1=$4 # << or <
inputDirective2=$5 # << or <
file=${input%.*}
#echo $file 
#> log.out.0.txt
#> log.out.1.txt

 as -g --gstabs+ "$file".s -o "$file".o
  ld -o "$file" "$file".o 
 #  ./"$file" < $input2 #ONN
 #  ./"$file" > $input3 #ONN
  rm "$file".o
   ./"$file" #$input2  $input3  #ON 4 stdio 64 ch5 but turned off <3
   #cat $input3 #ON 4 stdio 64 ch5 but turned off <3

 echo $?
   rm "$file"
 # cat log.out.0.txt
 # cat log.out.1.txt
