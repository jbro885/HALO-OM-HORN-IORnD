//🦸‍♂️️
//dedicated to my dotti sluggi Red Velvet 레드벨벳 'Birthday' MV
//🦸‍♂️️
//they could have EVERYTHING]nos(no xcuse) if they would help <<they will]noslo🔍️(juzt freeze them out of chat🔍️
//
//🧠️inode count is "SB-GLOBAL" cuz multithreading
// we can do multi floppy later. 
//🧠️ext2 is alot like fat, cept inf instead of inodes
//🧠️i actually think ext2 is chiller/ezr

//🤖️i really dont want u 2 write the c compiler

//🤖️or anything else by hand...{(above halo.c2s)
//🤖️ (restrap on riscv )}mini kernel or w/e 
////🤖️ the nn should beable 2 write "more kernel modules"
// and all its own programs. c-compiler, mex , EVERYTHING
// even a json parse. 
// honestly this and then {snake_NN +more_NN(just 2 prove-nn+nn priorities)} halo then riscv then minikern.
// should honestly be the last things u do by hand
// should even beable 2 rewrite itself...and add way more
// functions or w/e i dunno maybe its ok for it 2 be super simple and it can even restrap on c ,but what would u run it on ? (u would run "set of principles" like a programe...(with nn compiler or something
//it supposed 2 can write halo or c we will see
//(we will make it document itself after it writes
// working code as well(explain complicated chips
//based on patterns etc
//🤯️u could probably make it use same style "ECS"🤯️
//🤯️COULD BE 'INFINITE BUS OF CHIPS'(AS PROGS...)
//🤯️ THEN IT "COULD BE PHY"{ON A RISCV-ASIC /FLSHD.FPGA}
//make chips/hds? still smoller than nonexistent
//but i qluno wait quite a while b4 phy(phy3d machine sim)
//>w8 4 nvdia (dude it wont be ECS)
//NOBODY WANTS 2 CODE ON A BAD CODEBASE🛑️
//not gonna be foss either ,god4bid ud have 2 git creative🛑️
//🤖️i cant keep coding by hand tho
//🚉️ur good tho , on trac cuz we aint doin "FATFS"]3.13.24
//🤔️
// i learned something in .c TODAY glad 2 know c/MBA.
// and glad 2 have std4files & . c codes way faster etc.
//we even look at XBRL.c just 4 speed/scope.
// we could get u$er$ and inc with FOSS...
//were in better position than anyone 2 do revNGN the data
// and its not like u cant do w/e u want 
// ur the CEO who's gonna tell u wut 2 do? 
// can just accumulate block, and get item exchange TBAY
//4 a while , w/e p2p cloud let that manage itself
// dont take cash just take tokens etc. (see wut stix w/e
//i mean ppl can just play mex and thats fun. w/e

//🤔️🕵🏽‍♂️️<GOOGLEMEBITCH🔍️🕵🏽‍♂️️👩‍🌾️<they lie...😵‍💫️✳️🍀️🔍️🕵🏽‍♂️️
//+its good 2 have seperate "DIVISIONS" incase of team
//🚉️🚉️🚉️🚉️🚉️🚉️🚉️🚉️🚉️🚉️🚉️🚉️🚉️🚉️🚉️

// if finger hurts go do 2nd ethics/ math
///////////////////////////
#include <stdio.h> 
#include <stdlib.h> 
#include <pthread.h>

 #include <time.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>

extern char *std_superBLockFilename_H; //🤩️

extern int stdKbdAsciiSize_H;
char *stdAsciiBuffer_0;

///
//int read_block_count;
int read_inode_count;

int externStringInit(){

stdAsciiBuffer_0 = malloc(stdKbdAsciiSize_H);

}

//🦸‍♂️️
char* superBLock_filename_H[64];
char* blockfilename_Array_H[64][64];



//🦸‍♂️️
int main(int argc, char* argv[]){
externStringInit();


int rand_uid = std_rand(0, 65535); //0–65535

printf("rand_uid = %d \n", rand_uid);
//📮️
//still needs 2 be binary . 
// and could still collide. 
// so u probalby wanna use a hash of 
// proname and filename or w/e

// u dont have to involve hashing just 2 do this tho
//📮️
  converttobinaryMalloc(rand_uid, stdAsciiBuffer_0, stdKbdAsciiSize_H); 
   

//printf("stdAsciiBuffer_0 = %s \n", stdAsciiBuffer_0);
///////////////
free(stdAsciiBuffer_0);
///////////////

strcpy(blockfilename_Array_H[0],std_superBLockFilename_H); // can get by uuid later🔭️
//read_block_count = 1 ; //  ?

  
int read_inode_count = Std_read_inode_count_H(blockfilename_Array_H[0]);
int read_block_count = Std_read_block_count_H(blockfilename_Array_H[0]);
  
Std_createProBlock_H(blockfilename_Array_H[read_block_count],blockfilename_Array_H[0]);//
///// can get by uuid later🔭️
Std_inc_block_count_H(blockfilename_Array_H[0]); // both are created
Std_inc_inode_count_H(blockfilename_Array_H[0]);



printf("read_block_count= %d\n",read_block_count);
printf("read_inode_count=  %d\n",read_inode_count);

//Std_register_block_Inode(); //📌️

    return read_inode_count; 
} 

//🦸‍♂️️
//dedicated to my dotti sluggi Red Velvet 레드벨벳 'Birthday' MV
//🦸‍♂️️


// we will read afloppy  . u can fake mark it full
// and make it say insert new disk 2 continue. 
// then u could autochange disk name or w/e
// and save load 2 mult disks. but do basic first. 
// honestly just make bigger fs for now 
// nothing is a big deal having basic fs is more than enuff
// 4 halo bootstrap so dont bother. 
// everything is just "MORE kODING" at this point tbh



