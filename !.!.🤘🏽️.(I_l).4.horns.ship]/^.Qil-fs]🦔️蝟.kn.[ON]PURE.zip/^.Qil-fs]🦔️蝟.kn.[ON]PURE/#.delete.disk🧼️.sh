rm -rf disk[0000]
