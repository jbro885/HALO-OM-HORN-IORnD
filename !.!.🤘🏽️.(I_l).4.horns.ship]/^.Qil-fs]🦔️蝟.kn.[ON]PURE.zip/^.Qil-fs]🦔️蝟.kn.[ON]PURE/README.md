# share-test-lg-0000
testing sharing


how to run? 


sh #.run.all.sh

this will create a new directory and a cli only binary key logger . [it is a compilable  / editable replacement for "Ncurses" popular 
in many c-cli rougelike games]

when u understand this source code and feel ready i can introduce you to more of the modules. 


(it will not beable 2 run the last file but that doesnt' 
matter its still a cli keylogger
the next file is next in the process of 
writing "multiple filesystem inodes" it should be 
done by tonight or tomorrow then i will add 2 repo
and it will be a "TEXT EDITOR"
it worked before but im adding a BIG upgrade. 

(if u cant wait till then u can try messing with the #.mem.inspect🔬️]2]ON.c
if u can use this u probably understand this code pretty well



