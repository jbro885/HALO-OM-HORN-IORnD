#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
    //printf("hello, world\n");
    // can pass in rand uuid later🔭️
int exit_status_0 = WEXITSTATUS(system("./+x/0.sb.maqr[🦸‍♂️️🎫️]0001.+x"));
//Std_inc_block_count_H(disk[0000]/0000000000000000.pro); // can get by uuid later🔭️

int std_sb_count = 4 ; 
int desired_procs = 1 ;  // for kbd buffer/all else =inodes 
// using kbd as a "KNOWN GLOBAL DEFAULT" 4 all prgs 4 now
for(int i = 0; i < std_sb_count + desired_procs  ; i++){
system("./+x/0.pro.maqr+[🎫️]0001.+x");
//Std_inc_block_count_H(disk[0000]/0000000000000000.pro);
}
}


