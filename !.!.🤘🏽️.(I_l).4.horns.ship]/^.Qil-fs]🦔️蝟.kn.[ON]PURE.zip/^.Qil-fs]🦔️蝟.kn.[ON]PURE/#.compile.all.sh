sh z.c⚱[Wno]^H.sh 0.sb.maqr[🦸‍♂️️🎫️]0001.c
sh z.c⚱[Wno]^H.sh 0.fsmaqr]💾️🗄️.c
sh z.c⚱[Wno]^H.sh 0.pro.maqr+[🎫️]0001.c
sh z.c⚱[Wno]^H.sh 0.inode.maqr[🧠️🎫️]0000.c
sh z.c⚱[Wno]^H.sh 1.kb2.fs]⌨️🗃️]0000.c
sh z.c⚱[Wno]^H.sh 2.qi.lngn]🖌️🦾️]0000.c
sh z.c⚱[Wno]^H.sh 88.testKey]🪄️.c
#./97.mom4key]🪄️]0002.+x
